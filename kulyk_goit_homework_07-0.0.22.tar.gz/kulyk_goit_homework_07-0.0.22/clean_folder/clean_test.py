def hello():
    print('Hello!')
