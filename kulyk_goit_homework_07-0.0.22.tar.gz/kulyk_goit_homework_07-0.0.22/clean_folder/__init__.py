from .clean_test import hello
from .main import main


__all__ = ['hello', 'main']
